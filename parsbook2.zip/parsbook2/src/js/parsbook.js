function mediaQuerry(x){
    if(x.matches){
        document.body.style.overflow = "hidden";
    }
    else{
        document.body.style.overflow = "auto";
    }
}

function myFunction(){
    var x = document.getElementById("search");
    var y = document.getElementById("body");
    var z = window.matchMedia("(max-width: 700px)");
    document.getElementById("sticky-search").focus();
    x.style.transform = "scale(1, 1)";
    x.style.transition = ".1s ease";
    x.style.filter = "opacity(1)";
    mediaQuerry(z);
}

function closeFunction(){
    var y = document.getElementById("search");
    var x = document.getElementById("sticky");
    var z = document.getElementById("body");
    var g = document.getElementById("sticky-search");
    y.style.transform = "scale(0, 0)";
    y.style.transition = "none";
    x.style.transform = "translateY(250px)";
    z.style.overflow = "scroll";
    g.value = "";
}

function slideUp(){
    var z = document.getElementById("sticky");
    z.style.transform = "translateY(0px)";
}

function slideDown(){
    var x = document.getElementById("sticky");
    x.style.transform = "translateY(250px)";
}

function slideRight(){
    var x = document.getElementById("dashboard");
    x.style.transform = "translateX(18.5rem)";
}

function slideLeft(){
    let x = document.getElementById("dashboard");
    x.style.transform = "translateX(0)";
}
